Copyright (c) 2025 Figma

This source code is protected under international copyright law. All rights
reserved and protected by the copyright holders.
All contents of this code repository are confidential and only available to authorized individuals with the
permission of the copyright holders. If you encounter this source code and do not have
permission, please contact the copyright holders and delete this file.

Further, the contents of this repository are strictly for demonstration purposes only
and an Enterprise Agreement must be signed and in place between Payload CMS, Inc. and
the party seeking to use this code in any way outside of demonstration purposes.
