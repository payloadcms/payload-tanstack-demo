# @payloadcms/codemod

CLI for auto-migrating Payload projects across deprecations. Initial target: v3 -> v4.

## Usage

Run against your project root:

```bash
npx @payloadcms/codemod [path]
```

With no arguments, runs every registered transform against the current directory. Transforms are idempotent and no-op on code that doesn't match their pattern, so running the full set against a partially migrated project is safe.

### Flags

- `--transform <name>` — run a single transform by name.
- `--list` — print registered transforms.
- `--dry` — analyze only; write nothing.
- `--print` — print transformed sources to stdout instead of writing.

## How it works

The tool loads your project via [ts-morph](https://ts-morph.com/), using your `tsconfig.json` when present, otherwise globbing `**/*.{ts,tsx,js,jsx}` (excluding `node_modules`, `dist`, `.next`, `build`). Each registered transform is applied in order against the shared project; changes are saved at the end unless `--dry` or `--print` is passed.

## Transforms

- `migrate-list-view-select-api` — Removes `admin.enableListViewSelectAPI` from Collection Configs. The List View's Select API is the default in v4.
- `migrate-disabled-fields` — migrates `field.admin.disableListColumn`, `disableListFilter`, `disableGroupBy`, `disableBulkEdit` into the consolidated `field.admin.disabled` object form.
- `globals-components-edit` — Globals: rename `admin.components.elements` to `admin.components.edit` and hoist `Description` to top-level `admin.components.Description` to match Collection conventions.
- `migrate-force-select` — migrates `forceSelect: { ... }` on Collection/Global configs to a `select` function that augments the caller's `select` when present and returns `undefined` (preserving full-document reads) when not. Shallow values become a spread (`{ ...select, ... }`); nested values use `deepMergeSimple` from `payload/shared` (auto-imported) to preserve the previous deep-merge semantics. Non-literal values, sibling `select` already present, and unsupported member kinds are surfaced as notes for manual review.
- `migrate-hide-api-url` — migrates `admin.hideAPIURL: true` to `admin.components.views.edit.api.tab.condition: () => false` on collection and global configs.
- `migrate-aliased-exports` — rewrites imports of types and utilities that used to be re-exported from `@payloadcms/ui` and `@payloadcms/next/utilities` to their canonical sources in `payload` / `payload/shared`.
- `migrate-document-title-context` — migrates `title` and `setDocumentTitle` destructured from `useDocumentInfo()` to `useDocumentTitle()`. They were removed from `DocumentInfoContext` in v4 and now live on `DocumentTitleContext`.

## Contributing

To add a transform:

1. Create `src/transforms/<name>/` with `index.ts` exporting a `Transform`.
2. Add fixtures as `<case>.input.ts` and `<case>.output.ts` siblings of `index.ts`.
3. Add `index.test.ts` verifying both the fixture pair and idempotency (running the transform on the output produces the output unchanged).
4. Register in `src/registry.ts`.
5. Update the transform list in this README.

Ship the transform in the same PR as the deprecation it migrates.
